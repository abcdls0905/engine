#ifndef __glextQCOM_h_
#define __glextQCOM_h_
/*
** Copyright (C) 2009 Qualcomm
*/

#ifndef __glext_h_
#   include <GLES/glext.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* GL_AMD_EGL_image_external_layout_specifier */
#ifndef GL_AMD_EGL_image_external_layout_specifier
#define GL_AMD_EGL_image_external_layout_specifier 1
// YUV format
#define GL_YUV_AMD                                           0x8BC7
// YUV types
#define GL_YUYV_AMD                                          0x8BC8
#define GL_UYVY_AMD                                          0x8BC9
#define GL_NV21_AMD                                          0x8BCA
#define GL_YV12_AMD                                          0x8BCB
#define GL_NV21_TILED_AMD                                    0x8BCC
// YUV samplers
#define GL_SAMPLER_EXTERNAL_YUYV_AMD                         0x8BCD
#define GL_SAMPLER_EXTERNAL_UYVY_AMD                         0x8BCE
#define GL_SAMPLER_EXTERNAL_NV21_AMD                         0x8BCF
#define GL_SAMPLER_EXTERNAL_YV12_AMD                         0x8BD0
#define GL_SAMPLER_EXTERNAL_NV21_TILED_AMD                   0x8BD1
#endif

/* GL_OES_egl_image_external (DRAFT) */
#ifndef GL_OES_EGL_image_external
#define GL_OES_EGL_image_external 1
#define GL_TEXTURE_EXTERNAL_OES                              0x8D65
#define GL_SAMPLER_EXTERNAL_OES                              0x8D66
#define GL_TEXTURE_BINDING_EXTERNAL_OES                      0x8D67
#define GL_REQUIRED_TEXTURE_IMAGE_UNITS_OES                  0x8D68
#endif

/* QCOM_tiled_rendering */
#ifndef GL_QCOM_tiled_rendering
#define GL_QCOM_tiled_rendering 1
#define GL_COLOR_BUFFER_BIT0_QCOM                       0x00000001
#define GL_COLOR_BUFFER_BIT1_QCOM                       0x00000002
#define GL_COLOR_BUFFER_BIT2_QCOM                       0x00000004
#define GL_COLOR_BUFFER_BIT3_QCOM                       0x00000008
#define GL_COLOR_BUFFER_BIT4_QCOM                       0x00000010
#define GL_COLOR_BUFFER_BIT5_QCOM                       0x00000020
#define GL_COLOR_BUFFER_BIT6_QCOM                       0x00000040
#define GL_COLOR_BUFFER_BIT7_QCOM                       0x00000080
#define GL_DEPTH_BUFFER_BIT0_QCOM                       0x00000100
#define GL_DEPTH_BUFFER_BIT1_QCOM                       0x00000200
#define GL_DEPTH_BUFFER_BIT2_QCOM                       0x00000400
#define GL_DEPTH_BUFFER_BIT3_QCOM                       0x00000800
#define GL_DEPTH_BUFFER_BIT4_QCOM                       0x00001000
#define GL_DEPTH_BUFFER_BIT5_QCOM                       0x00002000
#define GL_DEPTH_BUFFER_BIT6_QCOM                       0x00004000
#define GL_DEPTH_BUFFER_BIT7_QCOM                       0x00008000
#define GL_STENCIL_BUFFER_BIT0_QCOM                     0x00010000
#define GL_STENCIL_BUFFER_BIT1_QCOM                     0x00020000
#define GL_STENCIL_BUFFER_BIT2_QCOM                     0x00040000
#define GL_STENCIL_BUFFER_BIT3_QCOM                     0x00080000
#define GL_STENCIL_BUFFER_BIT4_QCOM                     0x00100000
#define GL_STENCIL_BUFFER_BIT5_QCOM                     0x00200000
#define GL_STENCIL_BUFFER_BIT6_QCOM                     0x00400000
#define GL_STENCIL_BUFFER_BIT7_QCOM                     0x00800000
#define GL_MULTISAMPLE_BUFFER_BIT0_QCOM                 0x01000000
#define GL_MULTISAMPLE_BUFFER_BIT1_QCOM                 0x02000000
#define GL_MULTISAMPLE_BUFFER_BIT2_QCOM                 0x04000000
#define GL_MULTISAMPLE_BUFFER_BIT3_QCOM                 0x08000000
#define GL_MULTISAMPLE_BUFFER_BIT4_QCOM                 0x10000000
#define GL_MULTISAMPLE_BUFFER_BIT5_QCOM                 0x20000000
#define GL_MULTISAMPLE_BUFFER_BIT6_QCOM                 0x40000000
#define GL_MULTISAMPLE_BUFFER_BIT7_QCOM                 0x80000000
#ifdef GL_GLEXT_PROTOTYPES
GL_API void GL_APIENTRY glStartTilingQCOM(GLuint x, GLuint y, GLuint width, GLuint height,
                                              GLbitfield preserveMask);
GL_API void GL_APIENTRY glEndTilingQCOM(GLbitfield preserveMask);
#endif
typedef void (GL_APIENTRYP PFNGLSTARTTILINGQCOM) (GLuint x, GLuint y, GLuint width, GLuint height,
                                                  GLbitfield preserveMask);
typedef void (GL_APIENTRYP PFNGLENDTILINGQCOM) (GLbitfield preserveMask);
#endif

/* EXT_texture_compression_s3tc */
#ifndef GL_EXT_texture_compression_s3tc
#define GL_COMPRESSED_RGB_S3TC_DXT1_EXT                  0x83F0
#define GL_COMPRESSED_RGBA_S3TC_DXT1_EXT                 0x83F1
#define GL_COMPRESSED_RGBA_S3TC_DXT3_EXT                 0x83F2
#define GL_COMPRESSED_RGBA_S3TC_DXT5_EXT                 0x83F3
#endif

#ifdef __cplusplus
}
#endif

#endif /* __glextQCOM_h_ */

