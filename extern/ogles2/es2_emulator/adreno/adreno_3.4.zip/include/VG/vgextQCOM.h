/*=============================================================================
FILE:           vgextQCOM.h

SERVICES:       Q3Dimension OpenVG

DESCRIPTION:    VG Extension Implementation

PUBLIC CLASSES: Not Applicable

INITIALIZATION AND SEQUENCING REQUIREMENTS: Not Applicable

Copyright (c) 2009 QUALCOMM Incorporated.  All Rights Reserved.
QUALCOMM Proprietary and Confidential.
=============================================================================*/

#ifndef _VGEXTQCOM_H
#define _VGEXTQCOM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <VG/openvg.h>

#ifndef VG_API_ENTRYP
#   define VG_API_ENTRYP VG_API_ENTRY*
#endif

/*-------------------------------------------------------------------------------
 * QCOM extensions
 *------------------------------------------------------------------------------*/

typedef enum  {

#ifndef VG_QCOM_precompressed_image
  VG_ATITC                            =  0,
#endif

  VG_IMAGE_FORMAT_QCOM_FORCE_SIZE     = VG_MAX_ENUM
} VGImageFormatQCOM;

#ifndef VG_QCOM_PRECOMPRESSED_IMAGE
#define VG_QCOM_PRECOMPRESSED_IMAGE 1

#ifdef VG_VGEXT_PROTOTYPES
VG_API_CALL VGImage VG_API_ENTRY vgCreateImagePrecompressedQCOM(VGImageFormatQCOM compressedFormat, VGImageFormat uncompressedFormat, VGint width, VGint height, VGbitfield allowedQuality);
VG_API_CALL void    VG_API_ENTRY vgImageSubDataPrecompressedQCOM(VGImage image, const void* data, VGint dataStride, VGImageFormat dataFormat, VGint x, VGint y, VGint width, VGint height);
#endif
typedef VGImage (VG_API_ENTRYP PFNVGCREATEIMAGEPRECOMPRESSEDQCOMPROC) (VGImageFormatQCOM format, VGint width, VGint height, VGbitfield allowedQuality);
typedef void    (VG_API_ENTRYP PFNVGIMAGESUBDATAPRECOMPRESSEDQCOMPROC) (VGImage image, const void* data, VGint dataStride, VGImageFormat dataFormat, VGint x, VGint y, VGint width, VGint height);

#endif


#ifdef __cplusplus 
} /* extern "C" */
#endif

#endif /* _VGEXTQCOM_H */
